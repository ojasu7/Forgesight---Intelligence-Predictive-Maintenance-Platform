# ForgeSight

**Manufacturing signals → explainable anomaly scores → better production decisions.**

A working AI + Business hackathon prototype for a six-machine 3D-print farm. It runs locally in a browser, with a trained machine-learning model and a scheduling engine. There are no API keys, paid services, runtime Python dependencies, or external JavaScript libraries. Fonts are optional; system fallbacks work offline.

## Run it on Windows (or macOS/Linux)

1. Extract the project ZIP.
2. Open a terminal inside that folder.
3. Run `python -m http.server 8000 --directory dist` (on Windows, `py -m http.server 8000 --directory dist` also works).
4. Open `http://localhost:8000` in a browser.

Opening index.html directly as a file will not load the JSON model. Use the local server above. If Python is unavailable, use any static HTTP server; a Node alternative is `npx http-server dist -p 8000` (requires installing that package).

## The quickest demo

1. Click **Hold telemetry** for a stable recording.
2. Select **P03** and inject **Extrusion blockage**.
3. Inspect the altered sensor values, model classification, and signal deviations.
4. Click **Optimize production**. Compare baseline and proposed scenario costs and late orders.
5. Accept the sandbox plan, or take a machine offline and recalculate.
6. Open **Model & evidence** to show the training method, confusion matrix, and cost formula.
7. Download the sample CSV, reset, and import the CSV to demonstrate the upload path.

## Implemented features

- Six synthetic machine telemetry streams: temperature, vibration, motor current, extrusion flow.
- Fault injection for extrusion blockage, thermal instability, and mechanical vibration, at two severities.
- Real multinomial logistic regression inference from learned weights, with softmax normalization.
- Normal-class complement anomaly score; per-feature deviations from the synthetic healthy baseline.
- Material-constrained, deadline-aware queue scheduling with machine assignment and sequence local search.
- Baseline retention guarantees the proposed objective is no worse than the displayed compatible round-robin baseline.
- Gantt visualization, order-level delays, explicit cost assumptions, and a reversible sandbox plan acceptance.
- CSV import with validation; CSV and analysis JSON exports.
- Guided demo, model evidence, and submission materials.

## Architecture

```mermaid
flowchart TD
  A[Simulator or telemetry CSV] --> B[Six window features]
  B --> C[Trained logistic classifier]
  C --> D[Anomaly score and evidence]
  D --> E[Scheduling cost model]
  F[Orders and machine constraints] --> E
  E --> G[Dispatch and local search]
  G --> H[Baseline comparison and proposed plan]
```

## Model

`train_model.py` generates 3,600 training windows (900 per class, seed 41) and 1,200 held-out windows (300 per class, seed 2026). Each window contains 30 samples at a nominal 10-second interval. Fault severity varies from 0.2–1.0. Six features are standardized and a four-class logistic regression is trained using scikit-learn. Mean, scale, coefficients, intercepts, healthy-baseline statistics, and evaluation are exported to `dist/model.json`. Inference uses plain JavaScript in `dist/engine.js`.

Features: temperature standard deviation, temperature slope, mean motor current, mean vibration, mean extrusion flow, extrusion slope. Slopes are per sample; unlike the synthetic training set, imported windows shorter than 30 samples or sampled at other cadences are outside the training distribution.

**Held-out synthetic accuracy: 98.58%; macro F1: 0.986.** These are measurements on independent windows from the SAME simulator, not on real equipment. The simulator makes the classes recognizable. Synthetic performance is not evidence of industrial reliability. There is no failure countdown, calibrated physical failure probability, vision model, LLM, or claimed real-world savings.

The anomaly score is `1 − classifier P(normal)`. Contributions compare the selected-class versus normal-class standardized logit weights. The displayed sigma value measures a feature's absolute standardized deviation from healthy training data; it is not a causal explanation.

### Reproduce training (optional)

The app already includes the trained model. To retrain, use Python with NumPy and scikit-learn:

```bash
python -m pip install -r requirements.txt
python train_model.py
```

## Scheduling

Only queued, unstarted jobs are planned. Existing work is represented by each machine's fixed next-available time. The app does not stream actual print progress or send machine commands. Every job must use an online machine that supports its material.

1. Baseline: compatible round-robin assignment.
2. Candidate: earliest deadlines first, choosing the machine with the lowest incremental objective.
3. Up to four local-search passes: alternate machine assignments and dispatch-order swaps.
4. Retain the baseline if the candidate is worse.

This is a heuristic, not a guaranteed globally optimal solution. Scores weight hypothetical interruptions and waste, using adjustable assumptions:

```text
interruption = anomaly_score × downtime_minutes
duration = job_minutes / machine_speed
finish = machine_previous_finish + duration + interruption
delay_cost = max(0, finish − due) / 60 × late_penalty_per_hour
waste_proxy = anomaly_score × (material_cost + duration / 60 × machine_cost_per_hour)
objective = sum(delay_cost + waste_proxy)
```

The objective does not include measured profit, labor savings, clinical metrics, or actual maintenance benefits. Estimated interruptions are added to each queued job, a deliberately simple scenario assumption. Order value is display-only and does not determine prioritization. Changing cost assumptions recalculates a proposed plan. Accepted plans are local sandbox snapshots, not printer instructions. Changes to telemetry invalidate plans.

## CSV contract

Required header:

```csv
machine_id,timestamp,temp_c,vibration_mm_s,motor_a,extrusion_mm_s
```

Machine IDs: P01–P06. Timestamp: numeric seconds, distinct and equally spaced per machine. At least 12 samples; latest 30 used. Preferred cadence: 10 seconds to match training. Sensor units are included in column names. Imported machines are frozen at the supplied window; other machines remain simulated. Uploads never leave the browser. Max file size: 5 MB.

## Verification

```bash
npm test
```

Tests exercise independent JavaScript-generated fault classifications, probability normalization, material compatibility, no overlapping jobs, complete allocations, objective improvement, infeasibility, hand-calculated cost terms, and invalid CSV inputs. Node is needed only for tests, not for using the app. Browser visual QA was unavailable in the build environment; responsive styles are included but require manual visual confirmation.

## Files

- `dist/index.html`, `styles.css`, `app.js`: complete UI.
- `dist/engine.js`: deterministic sensor simulator, ML inference, CSV parsing, scheduler.
- `dist/model.json`: learned model and benchmark metadata.
- `train_model.py`: reproducible synthetic training and evaluation.
- `tests/engine.test.mjs`: meaningful computational tests.
- `submission.md`: Devpost draft, recording script, and honest project claims.

## Credits and scope

Prepared for Ojas Upadhye for ForgeHacks 2026, AI + Business. Development used ChatGPT/Codex assistance. Runtime ML was trained during this build using a new synthetic generator. No pre-existing private municipal dataset or physical machine data is included. The user should disclose AI-assisted development and describe their personal contribution accurately. Verify event requirements and eligibility directly with the organizers before submitting.

Next steps: collect labeled real-printer telemetry with permission; define machine-specific baselines; evaluate on held-out machines and time periods; calibrate scores; compare scheduling policy against operators and actual delays.
